-- trimmed from data.senat.fr dosleg.sql (10 October 2026) for tests
COPY scr (sesann, scrnum, code, scrint, scrdat, scrpou, scrcon, scrvot, scrsuf, scrvotsea, scrsufsea, scrpousea, scrconsea, scrmaj, scrmajsea, soslib, scrbaspag, scrdateff, scrjso) FROM stdin;
2025	170	30320	sur lensemble de la proposition de loi visant à garantir l'égal accès de tous à l'accompagnement et aux soins palliatifs	2026-01-28 00:00:00	307	17	341	324	341	324	307	17	0	0	\N	\N	\N	N
2025	169	30313	sur lensemble de la proposition de loi relative au droit à l'aide à mourir	2026-01-28 00:00:00	122	181	341	303	341	303	122	181	0	0	\N	\N	\N	N
2025	148	30307	sur lamendement n° 208 rectifié quater, présenté par Mme Marie-Pierre de la Gontrie et plusieurs de ses collègues, à larticle 4 de la proposition de loi relative au droit à l'aide à mourir	2026-01-20 00:00:00	127	148	299	275	299	275	127	148	0	0	\N	\N	\N	N
2025	317	31180	sur lensemble du projet de loi portant approbation des comptes de la sécurité sociale de lannée 2025	2026-06-22 00:00:00	226	106	341	332	341	332	226	106	0	0	\N	\N	\N	N
\.

COPY votsen (sesann, scrnum, senmat, posvotcod, titsencod, stavotidt, senmatdel, votsenmar) FROM stdin;
2025	169	04042C	1	0	0	\N	\N
2025	169	07033P	2	0	0	\N	\N
2025	169	07029T	3	0	0	\N	\N
2025	169	04033B	1	0	0	08056B	\N
2025	148	05012A	2	0	0	\N	\N
2025	148	04045F	1	0	0	\N	\N
2025	148	01058X	2	0	0	\N	\N
2025	148	04047H	2	0	0	\N	\N
2025	148	07004J	4	0	0	\N	\N
2025	148	04092N	2	0	0	\N	\N
2025	148	04042C	2	0	0	\N	\N
2025	169	04008A	1	0	0	\N	\N
2025	169	04070G	1	0	0	\N	\N
2025	169	05012A	1	0	0	\N	\N
2025	169	04045F	2	0	0	\N	\N
2025	169	01058X	1	0	0	\N	\N
2025	169	04047H	1	0	0	\N	\N
2025	169	07004J	2	0	0	21043B	\N
2025	169	04092N	2	0	0	20034V	\N
2025	170	05012A	1	0	0	\N	\N
2025	170	04045F	1	0	0	\N	\N
2025	170	01058X	1	0	0	\N	\N
2025	170	04047H	1	0	0	\N	\N
2025	170	07004J	1	0	0	21043B	\N
2025	170	04092N	1	0	0	20034V	\N
2025	170	04042C	1	0	0	\N	\N
2025	170	07033P	1	0	0	\N	\N
2025	170	07029T	1	0	0	\N	\N
2025	148	07033P	2	0	0	\N	\N
2025	148	07029T	3	0	0	\N	\N
2025	148	04033B	2	0	0	\N	\N
2025	148	04008A	2	0	0	\N	\N
2025	148	04070G	4	0	0	\N	\N
2025	170	04033B	1	0	0	08056B	\N
2025	170	04008A	1	0	0	\N	\N
2025	170	04070G	1	0	0	\N	\N
2025	317	04047H	1	0	0	\N	\N
2025	317	07004J	1	0	0	\N	\N
2025	317	07029T	1	0	0	\N	\N
2025	317	01058X	1	0	0	\N	\N
2025	317	04042C	1	0	0	\N	\N
2025	317	07033P	1	0	0	\N	\N
2025	317	04092N	1	0	0	\N	\N
2025	317	05012A	1	0	0	\N	\N
2025	317	04008A	1	0	0	\N	\N
2025	317	04070G	1	0	0	\N	\N
2025	317	04033B	1	0	0	\N	\N
2025	317	04045F	1	0	0	\N	\N
\.

COPY loi (loicod, typloicod, etaloicod, deccoccod, numero, signet, loient, motclef, loitit, loiint, urgence, url_jo, loinumjo, loidatjo, date_loi, loititjo, url_jo2, loinumjo2, loidatjo2, deccocurl, num_decision, date_decision, loicodmai, loinoudelibcod, motionloiorigcod, objet, url_ordonnance, saisine_date, saisine_par, loidatjo3, loinumjo3, url_jo3, url_an, url_presart, signetalt, orgcod, doscocurl, loiintori, proaccdat, proaccoppdat, retproaccdat, en_clair_url, en_clair_image, en_clair_chapo) FROM stdin;
76129       	ppl 	04	\N	2026-404  	ppl24-662	Égal accès de tous à l'accompagnement et aux soins palliatifs                   	\N	relative aux soins palliatifs et d'accompagnement                                                                                                                                                                                                              	visant à garantir l'égal accès de tous à l'accompagnement et aux soins palliatifs	\N	http://www.legifrance.gouv.fr/UnTexteDeJorf.do?numjo=SFHX2515568L	122                                 	2026-05-27 00:00:00	2026-05-26 00:00:00	visant à garantir l'égal accès de tous à l'accompagnement et aux soins palliatifs                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	\N	\N	\N	\N	\N	http://www.assemblee-nationale.fr/17/dossiers/soins_palliatifs_et_accompagnement_17e.asp	\N	\N	\N	\N	relative aux soins palliatifs et d'accompagnement	\N	\N	\N	/travaux-parlementaires/textes-legislatifs/la-loi-en-clair/proposition-de-loi-visant-a-garantir-legal-acces-de-tous-a-laccompagnement-et-aux-soins-palliatifs.html	/fileadmin/Illustrations/Legislatif/Af_soc/2025-2026/PPL_soins_palliatifs_AdobeStock_1745939479_cc_Audax.webp	Consultez "La loi en clair" pour décrypter le texte et découvrir les principaux apports du Sénat..
76127       	ppl 	04	01 	2026-794  	ppl24-661	Droit à l'aide à mourir                                                         	\N	relative au droit à l'aide à mourir                                                                                                                                                                                                                            	relative au droit à l'aide à mourir	\N	http://www.legifrance.gouv.fr/UnTexteDeJorf.do?numjo=SFHX2515569L	192                                 	2026-08-19 00:00:00	2026-08-18 00:00:00	relative au droit à l'aide à mourir                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             	\N	\N	\N	https://www.conseil-constitutionnel.fr/decision/2026/2026910DC.htm	2026-910 DC    	2026-08-14 00:00:00	\N	\N	\N		\N	2026-07-16 00:00:00	le Premier ministre, le Président du Sénat, au moins soixante sénateurs et au moins soixante députés	\N	\N	\N	http://www.assemblee-nationale.fr/17/dossiers/fin_de_vie_17e.asp	\N	\N	\N	\N	relative à la fin de vie	\N	\N	\N	/travaux-parlementaires/textes-legislatifs/la-loi-en-clair/proposition-de-loi-relative-au-droit-a-laide-a-mourir.html	/fileadmin/Illustrations/Legislatif/Af_soc/2024-2025/PPL_fin_de_vie_AdobeStock_198326452.webp	Consultez "La loi en clair" pour décrypter le texte et découvrir les principaux apports du Sénat
\.

COPY lecture (lecidt, loicod, typleccod, leccom) FROM stdin;
89262          	76127       	1  	Première lecture                                                                                                                                                                                                                                               
89264          	76129       	1  	Première lecture                                                                                                                                                                                                                                               
94112          	76127       	2  	Deuxième lecture                                                                                                                                                                                                                                               
94132          	76129       	2  	Deuxième lecture                                                                                                                                                                                                                                               
97192          	76127       	3  	Troisième lecture                                                                                                                                                                                                                                              
97493          	76127       	5  	Nouvelle lecture                                                                                                                                                                                                                                               
97252          	76127       	4  	Commission mixte paritaire (désaccord)                                                                                                                                                                                                                         
98892          	76127       	6  	Lecture définitive                                                                                                                                                                                                                                             
\.

COPY date_seance (lecidt, date_s, code, statut) FROM stdin;
89262          	2020-11-16 00:00:00	25237	\N
110045         	2026-06-22 00:00:00	31180	\N
100743         	2026-01-20 00:00:00	30307	\N
100743         	2026-01-28 00:00:00	30313	\N
100742         	2026-01-28 00:00:00	30320	\N
\.

COPY lecass (lecassidt, lecidt, codass, ordreass, sesann, ptlnum, ptlurl, ptlnumcpl, ptlnot, ptlurl2, ptlnot2, ptlurl3, ptlnot3, ptlnumcpl2, ptlnumcpl3, lecassame, lecassameses, orgcod, loiintmod, reucom, debatsurl, depot_only, lecassamedat, lecassamecomdat, orippr, libppr, sesppr, ptlurlcom, aliasppr, lecassamecom, lecassamesescom, ptlnumcom, lecassameado, lecassameadodat, lecassameadoses, lecassamecomado, lecassamecomadodat, lecassamecomadoses) FROM stdin;
100233         	89262          	A	1	2024	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	relative au droit à l'aide à mourir	\N	\N	non	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
100235         	89264          	A	1	2024	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	visant à garantir l'égal accès de tous à l'accompagnement et aux soins palliatifs	\N	\N	non	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
100742         	89264          	S	2	2025	44	/petite-loi-ameli/2025-2026/267.html	\N	\N	\N	\N	\N	\N	\N	\N	267	2025	SOCI	\N	\N	\N	non	2026-01-08 17:12:55	2026-01-05 13:43:28	\N	\N	\N	\N	\N	662	2024	\N	267	2026-01-26 17:29:38	2025	662	2026-01-07 12:14:13	2024
100743         	89262          	S	2	2025	43	/petite-loi-ameli/2025-2026/265.html	\N	\N	\N	\N	\N	\N	\N	\N	265	2025	SOCI	\N	\N	\N	non	2026-01-09 18:45:07	2025-09-09 11:49:03	\N	\N	\N	\N	\N	661	2024	\N	265	2026-01-20 23:20:52	2025	661	2026-01-07 11:29:08	2024
110841         	97493          	S	2	2025	156	/petite-loi-ameli/2025-2026/814.html	\N	\N	\N	\N	\N	\N	\N	\N	814	2025	SOCI	\N	\N	\N	non	2026-07-03 18:22:37	2026-07-01 07:32:30	\N	\N	\N	\N	\N	814	2025	\N	814	2026-07-07 16:16:21	2025	814	2026-07-01 11:02:35	2025
106981         	94132          	S	2	2025	108	/petite-loi-ameli/2025-2026/585.html	\N	\N	\N	\N	\N	\N	\N	\N	585	2025	SOCI	\N	\N	\N	non	2026-05-04 11:00:50	2026-03-23 15:04:57	\N	\N	\N	\N	\N	439	2025	\N	\N	\N	\N	\N	\N	\N
105521         	94132          	A	1	2025	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	non	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
109823         	97493          	A	1	2025	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	non	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
106982         	94112          	S	2	2025	109	/petite-loi-ameli/2025-2026/587.html	\N	\N	\N	\N	\N	\N	\N	\N	587	2025	SOCI	\N	\N	\N	non	2026-05-04 17:02:49	2026-03-23 15:05:42	\N	\N	\N	\N	\N	440	2025	\N	587	2026-05-11 18:33:48	2025	440	2026-04-29 10:09:32	2025
109461         	97252          	I	1	2025	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	PARI	\N	\N	\N	non	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
105501         	94112          	A	1	2025	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	non	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
111383         	98892          	A	1	2025	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	non	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.

COPY texte (texcod, oritxtcod, typtxtcod, typurl, lecassidt, sesann, orgcod, texnum, texurl, url2, url3, url4, url2txt, url3txt, url4txt, txtoritxtdat, prix, numerobis, texdatsea, reserve_comspe, datrejet_disc_immediate, texace, url_cnen) FROM stdin;
155531	4     	1  	E	100233         	2024	\N	1100	https://www.assemblee-nationale.fr/dyn/17/textes/l17b1100_proposition-loi#                                                                                                                                                                                     	\N	\N	\N	\N	\N	\N	2025-03-11 00:00:00	\N	\N	\N	\N	\N	\N	\N
155533	4     	1  	E	100235         	2024	\N	1102	https://www.assemblee-nationale.fr/dyn/17/textes/l17b1102_proposition-loi#                                                                                                                                                                                     	\N	\N	\N	\N	\N	\N	2025-03-11 00:00:00	\N	\N	\N	\N	\N	\N	\N
156176	5     	1  	E	100235         	0	\N	121	https://www.assemblee-nationale.fr/dyn/17/textes/l17t0121_texte-adopte-seance#                                                                                                                                                                                 	\N	\N	\N	\N	\N	\N	2025-05-27 00:00:00	\N	\N	\N	\N	\N	\N	\N
156177	0     	1  	I	100742         	2024	\N	662	ppl24-662.html                                                                                                                                                                                                                                                 	\N	\N	\N	\N	\N	\N	2025-05-27 00:00:00	1	\N	\N	oui	\N	N	\N
156178	5     	1  	E	100233         	0	\N	122	https://www.assemblee-nationale.fr/dyn/17/textes/l17t0122_texte-adopte-seance#                                                                                                                                                                                 	\N	\N	\N	\N	\N	\N	2025-05-27 00:00:00	\N	\N	\N	\N	\N	\N	\N
156179	0     	1  	I	100743         	2024	\N	661	ppl24-661.html                                                                                                                                                                                                                                                 	\N	\N	\N	\N	\N	\N	2025-05-27 00:00:00	\N	\N	\N	oui	\N	N	\N
156182	30    	1  	E	100235         	2024	\N	1281	https://www.assemblee-nationale.fr/dyn/17/textes/l17b1281_texte-adopte-commission#                                                                                                                                                                             	\N	\N	\N	\N	\N	\N	2025-04-11 00:00:00	\N	\N	\N	\N	\N	\N	\N
156183	30    	1  	E	100233         	2024	\N	1364	https://www.assemblee-nationale.fr/dyn/17/textes/l17b1364_texte-adopte-commission#                                                                                                                                                                             	\N	\N	\N	\N	\N	\N	2025-05-02 00:00:00	\N	\N	\N	\N	\N	\N	\N
160812	29    	1  	I	100743         	2025	\N	265	ppl25-265.html                                                                                                                                                                                                                                                 	\N	\N	\N	\N	\N	\N	2026-01-07 00:00:00	\N	\N	\N	\N	\N	N	\N
167005	3     	1  	E	109823         	2025	\N	2773	https://www.assemblee-nationale.fr/dyn/17/textes/l17b2773_proposition-loi#                                                                                                                                                                                     	\N	\N	\N	\N	\N	\N	2026-06-03 00:00:00	\N	\N	\N	non	\N	\N	\N
166253	8     	1  	I	106982         	2025	\N	109	tas25-109.html                                                                                                                                                                                                                                                 	\N	\N	\N	\N	\N	\N	2026-05-12 00:00:00	\N	\N	\N	\N	\N	N	\N
162572	30    	1  	E	105521         	2025	\N	2457	https://www.assemblee-nationale.fr/dyn/17/textes/l17b2457_texte-adopte-commission#                                                                                                                                                                             	\N	\N	\N	\N	\N	\N	2026-02-10 00:00:00	\N	\N	\N	non	\N	\N	\N
163479	5     	1  	E	105501         	0	\N	243	https://www.assemblee-nationale.fr/dyn/17/textes/l17t0243_texte-adopte-seance#                                                                                                                                                                                 	\N	\N	\N	\N	\N	\N	2026-02-25 00:00:00	\N	\N	\N	\N	\N	\N	\N
163480	0     	1  	I	106982         	2025	\N	440	ppl25-440.html                                                                                                                                                                                                                                                 	\N	\N	\N	\N	\N	\N	2026-02-25 00:00:00	\N	\N	\N	oui	\N	N	\N
165796	29    	1  	I	106982         	2025	\N	587	ppl25-587.html                                                                                                                                                                                                                                                 	\N	\N	\N	\N	\N	\N	2026-04-29 00:00:00	\N	\N	\N	\N	\N	N	\N
168873	14    	1  	E	111383         	0	\N	332	https://www.assemblee-nationale.fr/dyn/17/textes/l17t0332_texte-adopte-seance                                                                                                                                                                                  	\N	\N	\N	\N	\N	\N	2026-07-15 00:00:00	\N	\N	\N	\N	\N	\N	\N
168774	3     	1  	E	111383         	2025	\N	3059	https://www.assemblee-nationale.fr/dyn/17/textes/l17b3059_proposition-loi                                                                                                                                                                                      	\N	\N	\N	\N	\N	\N	2026-07-09 00:00:00	\N	\N	\N	\N	\N	\N	\N
163473	18    	1  	E	105521         	0	\N	242	https://www.assemblee-nationale.fr/dyn/17/textes/l17t0242_texte-adopte-seance#                                                                                                                                                                                 	\N	\N	\N	\N	\N	\N	2026-02-25 00:00:00	\N	\N	\N	\N	\N	\N	\N
163474	0     	1  	I	106981         	2025	\N	439	ppl25-439.html                                                                                                                                                                                                                                                 	\N	\N	\N	\N	\N	\N	2026-02-25 00:00:00	\N	\N	\N	oui	\N	N	\N
160832	29    	1  	I	100742         	2025	\N	267	ppl25-267.html                                                                                                                                                                                                                                                 	\N	\N	\N	\N	\N	\N	2026-01-07 00:00:00	\N	\N	\N	\N	\N	N	\N
168092	5     	1  	E	109823         	0	\N	323	https://www.assemblee-nationale.fr/dyn/17/textes/l17t0323_texte-adopte-seance                                                                                                                                                                                  	\N	\N	\N	\N	\N	\N	2026-06-30 00:00:00	\N	\N	\N	\N	\N	\N	\N
168093	0     	1  	I	110841         	2025	\N	814	ppl25-814.html                                                                                                                                                                                                                                                 	\N	\N	\N	\N	\N	\N	2026-06-30 00:00:00	\N	\N	\N	non	\N	N	\N
162195	30    	1  	E	105501         	2025	\N	2453	https://www.assemblee-nationale.fr/dyn/17/textes/l17b2453_texte-adopte-commission                                                                                                                                                                              	\N	\N	\N	\N	\N	\N	2026-02-05 00:00:00	\N	\N	\N	non	\N	\N	\N
161652	8     	1  	I	100743         	2025	\N	43	tas25-043.html                                                                                                                                                                                                                                                 	\N	\N	\N	\N	\N	\N	2026-01-28 00:00:00	\N	\N	\N	non	\N	N	\N
161695	3     	1  	E	105521         	2025	\N	2406	https://www.assemblee-nationale.fr/dyn/17/textes/l17b2406_proposition-loi                                                                                                                                                                                      	\N	\N	\N	\N	\N	\N	2026-01-28 00:00:00	\N	\N	\N	\N	\N	\N	\N
168596	27    	1  	I	110841         	2025	\N	156	tas25-156.html                                                                                                                                                                                                                                                 	\N	\N	\N	\N	\N	\N	2026-07-07 00:00:00	\N	\N	\N	non	\N	N	\N
166973	36    	1  	I	109461         	2025	\N	681	ppl25-681.html                                                                                                                                                                                                                                                 	\N	\N	\N	\N	\N	\N	2026-06-02 00:00:00	\N	\N	\N	\N	\N	N	\N
161672	3     	1  	E	105501         	2025	\N	2401	https://www.assemblee-nationale.fr/dyn/17/textes/l17b2401_proposition-loi                                                                                                                                                                                      	\N	\N	\N	\N	\N	\N	2026-01-28 00:00:00	\N	\N	\N	\N	\N	\N	\N
161692	7     	1  	I	100742         	2025	\N	44	tas25-044.html                                                                                                                                                                                                                                                 	\N	\N	\N	\N	\N	\N	2026-01-28 00:00:00	\N	\N	\N	non	\N	N	\N
165797	29    	1  	I	106981         	2025	\N	585	ppl25-585.html                                                                                                                                                                                                                                                 	\N	\N	\N	\N	\N	\N	2026-04-29 00:00:00	\N	\N	\N	\N	\N	N	\N
168114	36    	1  	I	110841         	2025	\N	826	ppl25-826.html                                                                                                                                                                                                                                                 	\N	\N	\N	\N	\N	\N	2026-07-01 00:00:00	\N	\N	\N	\N	\N	N	\N
166796	9     	1  	I	106981         	2025	\N	108	tas25-108.html                                                                                                                                                                                                                                                 	\N	\N	\N	\N	\N	\N	2026-05-11 00:00:00	\N	\N	\N	\N	\N	N	\N
167340	30    	1  	E	109823         	2025	\N	2915	https://www.assemblee-nationale.fr/dyn/17/textes/l17b2915_texte-adopte-commission                                                                                                                                                                              	\N	\N	\N	\N	\N	\N	2026-06-11 00:00:00	\N	rectifié	\N	\N	\N	\N	\N
\.

COPY typloi (typloicod, typloilib, groupe, typloiden, typloigen, typloitit, typloidenplu, typloide, typloiabr) FROM stdin;
ppro	proposition de loi de programmation                                             	ppl                                 	proposition de loi de programmation                                             	F	propositon de loi de programmation	propositions de loi de programmation	de la	PPL
pplc	proposition de loi constitutionnelle                                            	ppl                                 	proposition de loi constitutionnelle                                            	F	proposition de lois constitutionnelles	propositions de loi constitutionnelle	de la	PPLC
pjlr	projet de loi de finances rectificative                                         	pjl                                 	projet de loi de finances rectificative                                         	M	projet de lois de finances rectificatives	projets de loi de finances rectificatives	du	PLFR
pjlg	projet de loi de règlement                                                      	pjl                                 	projet de loi de règlement                                                      	M	projets de lois de règlement	projets de loi de règlement 	du	PJL
pjl 	projet de loi                                                                   	pjl                                 	projet de loi                                                                   	M	projets de lois	projets de loi 	du	PJL
pjlf	projet de loi de finances                                                       	pjl                                 	projet de loi de finances                                                       	M	projets de lois de finances	projets de loi de finances	du	PLF
ppl 	proposition de loi                                                              	ppl                                 	proposition de loi                                                              	F	propositions de lois	propositions de loi 	de la	PPL
mref	motion référendaire                                                             	\N	motion                                                                          	F	motions tendant à soumettre au référendum	motions	de la	Motion référendaire
pjfs	projet de loi de financement sécurité sociale                                   	pjl                                 	projet de loi de financement de la sécurité sociale                             	M	financement de la sécurité sociale	projets de loi de financement de la sécurité sociale	du	PLFSS
pjlo	projet de loi organique                                                         	pjl                                 	projet de loi organique                                                         	M	projets de lois origaniques	projets de loi organique	du	PJLO
pjlc	projet de loi constitutionnelle                                                 	pjl                                 	projet de loi  constitutionnelle                                                	M	projets de lois constitutionnelles	projets de loi constitutionnelle	du	PJLC
pplo	proposition de loi organique                                                    	ppl                                 	proposition de loi organique                                                    	F	propositions de lois organiques	propositions de loi organique	de la	PPLO
cvn 	convention                                                                      	cvn                                 	projet de loi                                                                   	M	conventions	projets de loi	du	PJL
pac 	résolution européenne                                                           	ppr                                 	proposition de résolution                                                       	F	résolutions européennes	propositions de résolution	de la	PPRE
ppre	modification réglement Sénat                                                    	ppr                                 	proposition de résolution                                                       	F	proposition de modification du réglement du Sénat	propositions de résolution	de la	PPR
enq 	commission d'enquête                                                            	ppr                                 	proposition de résolution                                                       	F	commissions d'enquêtes	propositions de résolution 	de la	PPR
ppra	proposition de résolution autre                                                 	ppr                                 	proposition de résolution                                                       	F	autres propositions de résolution	propositions de résolution	de la	PPR
pprp	résolution en application de l'article 34-1                                     	ppr                                 	proposition de résolution                                                       	F	propositions de résolution en application de l'article 34-1 de la Constitution	propositions de résolution	de la	PPR
refe	proposition de loi en application de l'article 11                               	ppl                                 	proposition de loi                                                              	F	propositions de loi en application du troisième alinéa de l'article 11	propositions de loi	de la	PPL
prog	projet de loi de programmation                                                  	pjl                                 	projet de loi de programmation                                                  	M	projets de loi de programmation	projets de loi de programmation	du	PJL
orie	Projet de loi d'orientation                                                     	pjl                                 	projet de loi d'orientation                                                     	M	projets de loi d'orientation	projets de loi d'orientation	du	PJL
cadr	projet de loi-cadre                                                             	pjl                                 	projet de loi-cadre                                                             	M	projets de loi-cadre	projets de loi-cadre	du	PJL
pfsr	projet de loi de financement rectificative de la sécurité sociale               	pjl                                 	projet de loi de financement rectificative de la sécurité sociale               	M	financement de la sécurité sociale	projets de loi de financement rectificative de la sécurité sociale	du	PLFRSS
dape	demande d'attribution des prérogatives d'une commission d'enquête               	dapce                               	demande d'attribution des prérogatives d'une commission d'enquête               	F	commissions d'enquêtes	demandes d'attribution des prérogatives d'une commission d'enquête	de la	PPR
\.

COPY etaloi (etaloicod, etaloilib) FROM stdin;
02	fusionné                            
05	caduc                               
04	promulgué ou adopté (ppr)           
01	en cours de discussion              
03	rejeté                              
06	retiré                              
\.

COPY stavot (stavotidt, stavotlib) FROM stdin;
0	Sans statut
1	Position de vote systématiquement pour
2	Position de vote systématiquement contre
3	Position de vote systématiquement abstention
4	Position de vote systématique
5	Congé
6	Excusé
7	Membre de la Haute Cour
8	Président de séance
9	Membre du gouvernement
10	Député
11	Député européen
12	Déport
\.

